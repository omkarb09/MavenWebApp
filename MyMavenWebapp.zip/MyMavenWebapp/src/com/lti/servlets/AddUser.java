package com.lti.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.model.User;

import com.lti.service.UserService;

public class AddUser extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String mobilenumber = request.getParameter("mobilenumber");
		
		User user = new User(firstname, lastname, mobilenumber);
		UserService service = new UserService();
		boolean result = service.addUser(user);
		
		PrintWriter out = response.getWriter();
		out.println("<td>User with username "+user.getFirstname()+" added</td>");
	}

}
