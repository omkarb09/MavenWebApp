package com.lti.service;

import java.util.List;

import com.lti.dao.UserDao;
import com.lti.model.User;



public class UserService {
	UserDao dao = null;
	public UserService(){
		dao = new UserDao();
	}
	
	public List<User> findAllUsers(){
		return dao.readAllUsers();
	}
	
	public boolean addUser(User user){
		int result = dao.createUser(user);
		if(result ==1)
			return true;
		else
			return false;
	}
}
