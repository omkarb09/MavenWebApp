package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.model.User;



public class UserDao {
private Connection conn;
	
	private void openConnection() throws SQLException, ClassNotFoundException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
	}
	private void closeConnection(){
		try{
			conn.close();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public List<User> readAllUsers(){
		List<User> users = null;
		try{
			openConnection();
			String query = "Select * From Users";
			Statement stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(query);
			users = new ArrayList<User>();
			while(result.next()){
				
				String fname = result.getString("Firstname");
				String lname = result.getString("Lastname");
				String mobile = result.getString("Mobilenumber");
				User user = new User(fname, lname, mobile);
				users.add(user);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return users;
	}
	
	public int createUser(User user){
		int result = 0;
		try {
			openConnection();
			String query = "Insert Into Users(Username, Password, Firstname, Lastname, mobilenumber) Values (?, ?, ?, ?, ?)";
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, "Default");
			pstmt.setString(2, "Default");
			pstmt.setString(3, user.getFirstname());
			pstmt.setString(4, user.getLastname());
			pstmt.setString(5, user.getMobilenumber());
			
			result = pstmt.executeUpdate();
		} 
		catch (ClassNotFoundException  e) 
		{
			e.printStackTrace();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally {
			closeConnection();
		}
		return result;
	}
}
